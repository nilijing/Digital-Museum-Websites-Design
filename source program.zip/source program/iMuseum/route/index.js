const express = require('express')
const mysql = require('mysql')

const db = mysql.createPool({
    user: 'root',
    host: 'localhost',
    password: '0000',
    database: 'imuseum'
})

module.exports = function () {
    const router = express.Router()

    router.get('/', (req, res) => {
        res.render('./index.ejs', {});
    });
    router.post('/', (req, res) => {
        let username = req.body.username;
        let password = req.body.password1;

        db.query(`INSERT INTO user (username,password) VALUE('${username}', '${password}')`, (err) => {
            if (err) {
                res.status(500).send('database error').end()
            } else {
                res.render('./index.ejs')
            }
        })

    })
    return router
}