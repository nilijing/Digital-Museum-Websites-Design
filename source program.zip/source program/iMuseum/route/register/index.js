const express = require('express');

module.exports = function () {
    const router = express.Router()

    router.get('/', (req,res)=>{
        res.render('./register/index.ejs')
    })

    return router
}