const express = require('express')
const mysql = require('mysql')

const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '0000',
    database: 'imuseum'
});

module.exports = function () {
    const router = express.Router()


    router.get('/', (req, res) => {
        if (req.query.city) {
            db.query(`SELECT * FROM museum_info WHERE city='${req.query.city}'`, (err, items) => {
                if (err) {
                    res.status(500).send('database error').end()
                } else {
                    res.render('./web/museums.ejs', {
                        items
                    })
                }
            })
        } else {
            res.send('no this city').end()
        }
    });

    return router
}