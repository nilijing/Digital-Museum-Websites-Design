const express = require('express')
const mysql = require('mysql')

const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '0000',
    database: 'imuseum'
});

module.exports = function () {
    const router = express.Router()


    router.get('/', (req, res) => {
        res.render('./web/index.ejs', {});
    });

    router.post('/', (req, res) => {
        let username = req.body.username;
        let password = req.body.password;
        db.query(`SELECT * FROM user WHERE username='${username}'`, (err, data) => {
            if (err) {
                console.error(err);
                res.status(500).send('database error').end();
            } else {
                if (data.length == 0) {
                    res.status(400).send('找不到该用户').end();
                } else {
                    if (data[0].password == password) {
                        //成功
                        res.redirect('/web');
                    } else {
                        res.status(400).send('密码错误').end();
                    }
                }
            }
        })
    })
    router.use('/museums', require('./museums.js')())
    router.use('/museums_detail', require('./detail.js')())
    return router
}