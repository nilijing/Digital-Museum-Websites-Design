const express = require('express')
const mysql = require('mysql')

const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '0000',
    database: 'imuseum'
});

module.exports = function () {
    const router = express.Router()


    router.get('/', (req, res) => {
        if (req.query.city && req.query.name) {
            db.query(`SELECT * FROM museum_info WHERE city='${req.query.city}' AND name='${req.query.name}'`, (err, item) => {
                if (err) {
                    res.status(500).send('database error').end()
                } else {
                    res.render('./web/detail.ejs', {
                        item
                    })
                }
            })
        } else {
            res.send('no this museum detail').end()
        }
    });

    return router
}