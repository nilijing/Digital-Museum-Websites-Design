const express = require('express')
const mysql = require('mysql')
const fs = require('fs')
const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '0000',
    database: 'imuseum'
});

module.exports = function () {
    const router = express.Router()

    router.get('/', (req, res) => {
        if (!req.query.mod_id) {
            db.query(`SELECT * FROM admin`, (err, data) => {
                if (err) {
                    console.error(err);
                    res.status(500).send('database error').end();
                } else {
                    db.query(`SELECT * FROM museum_info limit ${req.query.page*13-13},13`, (err, museums) => {
                        if (err) {
                            console.error(err);
                            res.status(500).send('database error').end();
                        } else {

                            res.render('./admin/delete.ejs', {
                                admin: data[0],
                                page: req.query.page,
                                museums
                            });
                        }
                    })
                }
            })
        }else{
            db.query(`SELECT * FROM museum_info WHERE ID=${req.query.mod_id}`, (err, data) => {
                if (err) {
                    console.error(err);
                    res.status(500).send('database error').end();
                } else if (data.length == 0) {
                    res.status(404).send('old file not found').end();
                } else {
                    
                    fs.unlink('static/upload/' + data[0].figure, (err) => {
                        if (err) {
                            console.error(err);
                            res.status(500).send('file opration error').end();
                        } else{
                            db.query(`DELETE FROM museum_info WHERE id = ${req.query.mod_id}`, (err) => {
                                if (err) {
                                    console.error(err);
                                    res.status(500).send('database error').end();
                                } else {
                                    db.query(`SELECT * FROM admin`, (err, admin) => {
                                        if (err) {
                                            console.error(err);
                                            res.status(500).send('database error').end();
                                        } else {
                                            db.query(`SELECT * FROM museum_info limit ${req.query.page*13-13},13`, (err, museums) => {
                                                if (err) {
                                                    console.error(err);
                                                    res.status(500).send('database error').end();
                                                } else {
                        
                                                    res.render('./admin/delete.ejs', {
                                                        admin: admin[0],
                                                        page: req.query.page,
                                                        museums
                                                    });
                                                }
                                            })
                                        }
                                    })
                                }
                            })
                        }
                    });
                }
            });

        }



    })


    return router
}