const express = require('express')
const mysql = require('mysql')

const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '0000',
    database: 'imuseum'
});

module.exports = function () {
    const router = express.Router()
    router.get('/', (req, res) => {

        db.query(`SELECT * FROM museum_info limit ${req.query.page*13-13},13`, (err, museums) => {
            if (err) {
                console.error(err);
                res.status(500).send('database error').end();
            } else {

                res.render('./admin/index.ejs', {
                    admin: {
                        username: req.query.admin
                    },
                    page: req.query.page,
                    museums
                });
            }
        })


    })
    router.post('/', (req, res) => {
        let username = req.body.username;
        let password = req.body.password;
        db.query(`SELECT * FROM admin WHERE username='${username}'`, (err, data) => {
            if (err) {
                console.error(err);
                res.status(500).send('database error').end();
            } else {
                if (data.length == 0) {
                    res.status(400).send('找不到该管理员').end();
                } else {
                    if (data[0].password == password) {
                        //成功
                        db.query(`SELECT * FROM museum_info limit 13`, (err, museums) => {
                            if (err) {
                                console.error(err);
                                res.status(500).send('database error').end();
                            } else {
                                res.render('./admin/index.ejs', {
                                    admin: data[0],
                                    page: 1,
                                    museums
                                });
                            }
                        })

                    } else {
                        res.status(400).send('密码错误').end();
                    }
                }
            }
        })
    })

    router.use('/add', require('./add.js')())
    router.use('/modify', require('./modify.js')())
    router.use('/delete', require('./delete.js')())

    return router
}