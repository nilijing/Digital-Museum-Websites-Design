const express = require('express')
const mysql = require('mysql')
const pathLib = require('path')

const fs = require('fs')
const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '0000',
    database: 'imuseum'
});

module.exports = function () {
    const router = express.Router()

    router.get('/', (req, res) => {
        if (req.query.mod_id) {
            db.query(`SELECT * FROM admin`, (err, data) => {
                if (err) {
                    console.error(err);
                    res.status(500).send('database error').end();
                } else {
                    db.query(`SELECT * FROM museum_info WHERE id=${req.query.mod_id}`, (err, will_mod) => {
                        if (err) {
                            console.error(err);
                            res.status(500).send('database error').end();
                        } else {
                            res.render('./admin/modify.ejs', {
                                admin: data[0],
                                will_mod: will_mod[0],
                                msg: ''
                            });
                        }
                    })

                }
            })

        }
    })
    router.post('/', (req, res) => {
        let city = req.body.city;
        let name = req.body.name;
        let time = req.body.time;
        let address = req.body.address;
        let cost = req.body.cost;
        let description = req.body.description;

        if (req.files[0]) {
            var ext = pathLib.parse(req.files[0].originalname).ext;

            var oldPath = req.files[0].path;
            var newPath = oldPath + ext;

            var newFileName = req.files[0].filename + ext;
        } else {
            var newFileName = null;
        }

        if (newFileName) {
            fs.rename(oldPath, newPath, (err) => {
                if (err) {
                    console.error(err);
                    res.status(500).send('file opration error').end();
                } else {
                    if (req.body.mod_id) { //修改
                        //先删除老的
                        db.query(`SELECT * FROM museum_info WHERE ID=${req.body.mod_id}`, (err, data) => {
                            if (err) {
                                console.error(err);
                                res.status(500).send('database error').end();
                            } else if (data.length == 0) {
                                res.status(404).send('old file not found').end();
                            } else {
                                fs.unlink('static/upload/' + data[0].figure, (err) => {
                                    if (err) {
                                        console.error(err);
                                        res.status(500).send('file opration error').end();
                                    } else {
                                        db.query(`UPDATE museum_info SET city='${city}', figure='${newFileName}', name='${name}', time='${time}', address='${address}', cost='${cost}', description='${description}' WHERE ID=${req.body.mod_id}`, (err) => {
                                            if (err) {
                                                console.error(err);
                                                res.status(500).send('database error').end();
                                            } else {
                                                db.query(`SELECT * FROM admin`, (err, admin) => {
                                                    if (err) {
                                                        console.error(err);
                                                        res.status(500).send('database error').end();
                                                    } else {
                                                        db.query(`SELECT * FROM museum_info WHERE id=${req.body.mod_id}`, (err, will_mod) => {
                                                            if (err) {
                                                                console.error(err);
                                                                res.status(500).send('database error').end();
                                                            } else {
                                                                res.render('./admin/modify.ejs', {
                                                                    admin: admin[0],
                                                                    will_mod: will_mod[0],
                                                                    msg: '修改成功'
                                                                });
                                                            }
                                                        })
                                                    }
                                                })
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    }
                }
            })
        } else {
            db.query(`UPDATE museum_info SET city='${city}', name='${name}', time='${time}', address='${address}', cost='${cost}', description='${description}' WHERE ID=${req.body.mod_id}`, (err) => {
                if (err) {
                    console.error(err);
                    res.status(500).send('database error').end();
                } else {
                    db.query(`SELECT * FROM admin`, (err, data) => {
                        if (err) {
                            console.error(err);
                            res.status(500).send('database error').end();
                        } else {
                            db.query(`SELECT * FROM museum_info WHERE id=${req.body.mod_id}`, (err, will_mod) => {
                                if (err) {
                                    console.error(err);
                                    res.status(500).send('database error').end();
                                } else {
                                    res.render('./admin/modify.ejs', {
                                        admin: data[0],
                                        will_mod: will_mod[0],
                                        msg: '修改成功'
                                    });
                                }
                            })

                        }
                    })
                }
            });
        }
    })

    return router
}