let left_li = document.querySelectorAll('.left ul li')
let pathname = location.pathname;
if (pathname.indexOf('add') != -1) {
    left_li[1].classList.add('bgColor')
    left_li[1].children[0].classList.add('fontColor')
    left_li[1].children[1].classList.add('fontColor')
} else if (pathname.indexOf('modify') != -1) {
    left_li[2].classList.add('bgColor')
    left_li[2].children[0].classList.add('fontColor')
    left_li[2].children[1].classList.add('fontColor')
} else if (pathname.indexOf('delete') != -1) {
    left_li[3].classList.add('bgColor')
    left_li[3].children[0].classList.add('fontColor')
    left_li[3].children[1].classList.add('fontColor')
} else {
    left_li[0].classList.add('bgColor')
    left_li[0].children[0].classList.add('fontColor')
    left_li[0].children[1].classList.add('fontColor')
}